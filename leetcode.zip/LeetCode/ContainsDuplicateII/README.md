### Explanation

- Make a hashset to store the index of each value found.
- If there is a duplicate in the hashset then check the condition and if true return.
- Else add the index of the current value in the hashset (key being current value)

