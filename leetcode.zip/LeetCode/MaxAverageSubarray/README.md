### Explanation

- We don't need to store the averages, just the max values
- Instead of creating a new total, we just add the incoming value and subtract the outgoing.

